daEmail = "exampleEmail@gmail.com" #put discord email here
daPassword = "examplePassword1234" #put discord password here
def getCreds():
    return(daEmail,daPassword)